/**
 * SEVOLF — GLOBAL JAVASCRIPT CONTROLLER
 */

document.addEventListener('DOMContentLoaded', () => {
  initMobileMenu();
  initAccordions();
  initCartDrawer();
  initVariantSelectors();
  initQuickAdd();
});

/* Mobile Menu */
function initMobileMenu() {
  const toggles = document.querySelectorAll('[data-mobile-menu-toggle]');
  const menu = document.querySelector('[data-mobile-menu]');
  if (!toggles.length || !menu) return;

  toggles.forEach(toggle => {
    toggle.addEventListener('click', () => {
      const isOpen = menu.classList.toggle('is-active');
      toggles.forEach(t => t.setAttribute('aria-expanded', isOpen));
      document.body.classList.toggle('overflow-hidden', isOpen);
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && menu.classList.contains('is-active')) {
      menu.classList.remove('is-active');
      toggles.forEach(t => t.setAttribute('aria-expanded', 'false'));
      document.body.classList.remove('overflow-hidden');
    }
  });
}

/* Accordions */
function initAccordions() {
  const headers = document.querySelectorAll('[data-accordion-header]');
  headers.forEach(header => {
    header.addEventListener('click', () => {
      const item = header.closest('.accordion__item');
      if (item) {
        item.classList.toggle('is-open');
      }
    });
  });
}

/* Cart Drawer Controller */
function initCartDrawer() {
  const triggers = document.querySelectorAll('[data-cart-drawer-trigger]');
  const drawer = document.querySelector('[data-cart-drawer]');
  const overlay = document.querySelector('[data-cart-drawer-overlay]');
  const closeBtns = document.querySelectorAll('[data-cart-drawer-close]');

  if (!drawer) return;

  const openDrawer = () => {
    drawer.classList.add('is-active');
    if (overlay) overlay.classList.add('is-active');
    document.body.style.overflow = 'hidden';
  };

  const closeDrawer = () => {
    drawer.classList.remove('is-active');
    if (overlay) overlay.classList.remove('is-active');
    document.body.style.overflow = '';
  };

  triggers.forEach(t => t.addEventListener('click', (e) => {
    e.preventDefault();
    openDrawer();
  }));

  closeBtns.forEach(c => c.addEventListener('click', closeDrawer));
  if (overlay) overlay.addEventListener('click', closeDrawer);

  window.SevolfCart = {
    open: openDrawer,
    close: closeDrawer,
    refresh: fetchCart
  };
}

/* Variant Selectors */
function initVariantSelectors() {
  const variantInputs = document.querySelectorAll('input[name="id"]');
  const optionInputs = document.querySelectorAll('.variant-radio-input');

  optionInputs.forEach(input => {
    input.addEventListener('change', () => {
      // Find matching variant JSON embedded in template
      const form = input.closest('form');
      const variantDataEl = form.querySelector('[data-variants-json]');
      if (!variantDataEl) return;

      try {
        const variants = JSON.parse(variantDataEl.textContent);
        const selectedOptions = Array.from(form.querySelectorAll('.variant-radio-input:checked')).map(i => i.value);
        
        const matched = variants.find(v => {
          return v.options.every((opt, idx) => opt === selectedOptions[idx]);
        });

        if (matched) {
          const masterIdInput = form.querySelector('input[name="id"]');
          if (masterIdInput) masterIdInput.value = matched.id;

          const submitBtn = form.querySelector('[type="submit"]');
          const priceDisplay = document.querySelector('[data-price-display]');

          if (matched.available) {
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.textContent = submitBtn.dataset.originalText || submitBtn.textContent.trim();
            }
          } else {
            if (submitBtn) {
              if (!submitBtn.dataset.originalText) {
                submitBtn.dataset.originalText = submitBtn.textContent.trim();
              }
              submitBtn.disabled = true;
              submitBtn.textContent = 'Sold Out';
            }
          }

          if (priceDisplay && matched.price) {
            priceDisplay.innerHTML = formatMoney(matched.price);
          }

          // Update variant featured image if present
          if (matched.featured_image && matched.featured_image.src) {
            const mainImg = document.querySelector('.product-gallery__item img');
            if (mainImg) {
              mainImg.src = matched.featured_image.src;
            }
          }

          // Update browser URL with variant ID seamlessly
          if (window.history && window.history.replaceState) {
            const newUrl = new URL(window.location.href);
            newUrl.searchParams.set('variant', matched.id);
            window.history.replaceState({ path: newUrl.href }, '', newUrl.href);
          }
        }
      } catch (err) {
        console.error('Variant matching error:', err);
      }
    });
  });
}

/* Quick Add to Cart with Shopify AJAX API */
function initQuickAdd() {
  document.addEventListener('submit', async (e) => {
    const form = e.target.closest('form[action*="/cart/add"]');
    if (!form) return;

    e.preventDefault();
    const submitBtn = form.querySelector('[type="submit"]');
    const originalText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span>Adding...</span>';
    }

    try {
      const formData = new FormData(form);
      const res = await fetch('/cart/add.js', {
        method: 'POST',
        body: formData,
        headers: { 'Accept': 'application/json' }
      });

      if (!res.ok) throw new Error('Add to cart failed');

      await fetchCart();
      if (window.SevolfCart) {
        window.SevolfCart.open();
      }
    } catch (err) {
      console.error(err);
      alert('Unable to add item to bag. Please try again.');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    }
  });
}

/* Fetch & Render Cart Drawer */
async function fetchCart() {
  try {
    const res = await fetch('/cart.js');
    const cart = await res.json();

    // Update cart counter badges
    const counters = document.querySelectorAll('[data-cart-count]');
    counters.forEach(c => {
      c.textContent = cart.item_count;
      c.style.display = cart.item_count > 0 ? 'flex' : 'none';
    });

    const itemsContainer = document.querySelector('[data-cart-drawer-items]');
    const subtotalEl = document.querySelector('[data-cart-drawer-subtotal]');

    if (subtotalEl) {
      subtotalEl.innerHTML = formatMoney(cart.total_price);
    }

    if (itemsContainer) {
      if (cart.item_count === 0) {
        itemsContainer.innerHTML = '<p style="text-align:center; padding: 2rem 0; color: var(--color-text-muted);">Your bag is currently empty.</p>';
      } else {
        itemsContainer.innerHTML = cart.items.map(item => `
          <div class="cart-drawer__item" data-line-item-key="${item.key}">
            <img class="cart-drawer__item-img" src="${item.featured_image ? item.featured_image.url : ''}" alt="${item.title}" />
            <div class="cart-drawer__item-info">
              <h4>${item.product_title}</h4>
              ${item.variant_title ? `<p class="cart-drawer__item-variant">${item.variant_title}</p>` : ''}
              <div style="display:flex; justify-content:space-between; align-items:center; margin-top: 0.5rem;">
                <div class="cart-drawer__quantity">
                  <button type="button" class="cart-drawer__qty-btn" onclick="updateCartLine('${item.key}', ${item.quantity - 1})">-</button>
                  <span class="cart-drawer__qty-num">${item.quantity}</span>
                  <button type="button" class="cart-drawer__qty-btn" onclick="updateCartLine('${item.key}', ${item.quantity + 1})">+</button>
                </div>
                <strong>${formatMoney(item.final_line_price)}</strong>
              </div>
            </div>
          </div>
        `).join('');
      }
    }
  } catch (err) {
    console.error('Fetch cart error:', err);
  }
}

window.updateCartLine = async function(key, quantity) {
  try {
    await fetch('/cart/change.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ id: key, quantity })
    });
    fetchCart();
  } catch (err) {
    console.error('Update line error:', err);
  }
};

function formatMoney(cents) {
  return '₹' + (cents / 100).toFixed(2);
}
